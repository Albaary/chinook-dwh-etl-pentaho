--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE staging_chinook;
--
-- Name: staging_chinook; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE staging_chinook WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE staging_chinook OWNER TO postgres;

\unrestrict (null)
\connect staging_chinook
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: log; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA log;


ALTER SCHEMA log OWNER TO postgres;

--
-- Name: staging; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA staging;


ALTER SCHEMA staging OWNER TO pg_database_owner;

--
-- Name: SCHEMA staging; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA staging IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: log_table_entry; Type: TABLE; Schema: log; Owner: postgres
--

CREATE TABLE log.log_table_entry (
    table_name character varying(100),
    input_date timestamp without time zone
);


ALTER TABLE log.log_table_entry OWNER TO postgres;

--
-- Name: staging_log; Type: TABLE; Schema: log; Owner: postgres
--

CREATE TABLE log.staging_log (
    table_name character varying(100),
    source_records integer,
    source_date timestamp without time zone,
    target_records integer,
    target_date timestamp without time zone,
    etl_date_start timestamp without time zone,
    logical character varying(100)
);


ALTER TABLE log.staging_log OWNER TO postgres;

--
-- Name: album; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.album (
    album_id integer NOT NULL,
    title character varying(160) NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE staging.album OWNER TO postgres;

--
-- Name: artist; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.artist (
    artist_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE staging.artist OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.customer (
    customer_id integer NOT NULL,
    first_name character varying(40) NOT NULL,
    last_name character varying(20) NOT NULL,
    company character varying(80),
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postal_code character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60) NOT NULL,
    support_rep_id integer
);


ALTER TABLE staging.customer OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.employee (
    employee_id integer NOT NULL,
    last_name character varying(20) NOT NULL,
    first_name character varying(20) NOT NULL,
    title character varying(30),
    reports_to integer,
    birth_date timestamp without time zone,
    hire_date timestamp without time zone,
    address character varying(70),
    city character varying(40),
    state character varying(40),
    country character varying(40),
    postal_code character varying(10),
    phone character varying(24),
    fax character varying(24),
    email character varying(60)
);


ALTER TABLE staging.employee OWNER TO postgres;

--
-- Name: genre; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.genre (
    genre_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE staging.genre OWNER TO postgres;

--
-- Name: invoice; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.invoice (
    invoice_id integer NOT NULL,
    customer_id integer NOT NULL,
    invoice_date timestamp without time zone NOT NULL,
    billing_address character varying(70),
    billing_city character varying(40),
    billing_state character varying(40),
    billing_country character varying(40),
    billing_postal_code character varying(10),
    total numeric(10,2) NOT NULL
);


ALTER TABLE staging.invoice OWNER TO postgres;

--
-- Name: invoice_line; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.invoice_line (
    invoice_line_id integer NOT NULL,
    invoice_id integer NOT NULL,
    track_id integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE staging.invoice_line OWNER TO postgres;

--
-- Name: media_type; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.media_type (
    media_type_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE staging.media_type OWNER TO postgres;

--
-- Name: playlist; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.playlist (
    playlist_id integer NOT NULL,
    name character varying(120)
);


ALTER TABLE staging.playlist OWNER TO postgres;

--
-- Name: playlist_track; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.playlist_track (
    playlist_id integer NOT NULL,
    track_id integer NOT NULL
);


ALTER TABLE staging.playlist_track OWNER TO postgres;

--
-- Name: track; Type: TABLE; Schema: staging; Owner: postgres
--

CREATE TABLE staging.track (
    track_id integer NOT NULL,
    name character varying(200) NOT NULL,
    album_id integer,
    media_type_id integer NOT NULL,
    genre_id integer,
    composer character varying(220),
    milliseconds integer NOT NULL,
    bytes integer,
    unit_price numeric(10,2) NOT NULL
);


ALTER TABLE staging.track OWNER TO postgres;

--
-- Data for Name: log_table_entry; Type: TABLE DATA; Schema: log; Owner: postgres
--

COPY log.log_table_entry (table_name, input_date) FROM stdin;
\.
COPY log.log_table_entry (table_name, input_date) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: staging_log; Type: TABLE DATA; Schema: log; Owner: postgres
--

COPY log.staging_log (table_name, source_records, source_date, target_records, target_date, etl_date_start, logical) FROM stdin;
\.
COPY log.staging_log (table_name, source_records, source_date, target_records, target_date, etl_date_start, logical) FROM '$$PATH$$/5096.dat';

--
-- Data for Name: album; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.album (album_id, title, artist_id) FROM stdin;
\.
COPY staging.album (album_id, title, artist_id) FROM '$$PATH$$/5088.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.artist (artist_id, name) FROM stdin;
\.
COPY staging.artist (artist_id, name) FROM '$$PATH$$/5084.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.customer (customer_id, first_name, last_name, company, address, city, state, country, postal_code, phone, fax, email, support_rep_id) FROM stdin;
\.
COPY staging.customer (customer_id, first_name, last_name, company, address, city, state, country, postal_code, phone, fax, email, support_rep_id) FROM '$$PATH$$/5091.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.employee (employee_id, last_name, first_name, title, reports_to, birth_date, hire_date, address, city, state, country, postal_code, phone, fax, email) FROM stdin;
\.
COPY staging.employee (employee_id, last_name, first_name, title, reports_to, birth_date, hire_date, address, city, state, country, postal_code, phone, fax, email) FROM '$$PATH$$/5089.dat';

--
-- Data for Name: genre; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.genre (genre_id, name) FROM stdin;
\.
COPY staging.genre (genre_id, name) FROM '$$PATH$$/5085.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.invoice (invoice_id, customer_id, invoice_date, billing_address, billing_city, billing_state, billing_country, billing_postal_code, total) FROM stdin;
\.
COPY staging.invoice (invoice_id, customer_id, invoice_date, billing_address, billing_city, billing_state, billing_country, billing_postal_code, total) FROM '$$PATH$$/5092.dat';

--
-- Data for Name: invoice_line; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.invoice_line (invoice_line_id, invoice_id, track_id, unit_price, quantity) FROM stdin;
\.
COPY staging.invoice_line (invoice_line_id, invoice_id, track_id, unit_price, quantity) FROM '$$PATH$$/5093.dat';

--
-- Data for Name: media_type; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.media_type (media_type_id, name) FROM stdin;
\.
COPY staging.media_type (media_type_id, name) FROM '$$PATH$$/5086.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.playlist (playlist_id, name) FROM stdin;
\.
COPY staging.playlist (playlist_id, name) FROM '$$PATH$$/5087.dat';

--
-- Data for Name: playlist_track; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.playlist_track (playlist_id, track_id) FROM stdin;
\.
COPY staging.playlist_track (playlist_id, track_id) FROM '$$PATH$$/5094.dat';

--
-- Data for Name: track; Type: TABLE DATA; Schema: staging; Owner: postgres
--

COPY staging.track (track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price) FROM stdin;
\.
COPY staging.track (track_id, name, album_id, media_type_id, genre_id, composer, milliseconds, bytes, unit_price) FROM '$$PATH$$/5090.dat';

--
-- Name: album album_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.album
    ADD CONSTRAINT album_pkey PRIMARY KEY (album_id);


--
-- Name: artist artist_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (artist_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- Name: genre genre_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.genre
    ADD CONSTRAINT genre_pkey PRIMARY KEY (genre_id);


--
-- Name: invoice_line invoice_line_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.invoice_line
    ADD CONSTRAINT invoice_line_pkey PRIMARY KEY (invoice_line_id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoice_id);


--
-- Name: media_type media_type_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.media_type
    ADD CONSTRAINT media_type_pkey PRIMARY KEY (media_type_id);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (playlist_id);


--
-- Name: playlist_track playlist_track_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.playlist_track
    ADD CONSTRAINT playlist_track_pkey PRIMARY KEY (playlist_id, track_id);


--
-- Name: track track_pkey; Type: CONSTRAINT; Schema: staging; Owner: postgres
--

ALTER TABLE ONLY staging.track
    ADD CONSTRAINT track_pkey PRIMARY KEY (track_id);


--
-- Name: album_artist_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX album_artist_id_idx ON staging.album USING btree (artist_id);


--
-- Name: customer_support_rep_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX customer_support_rep_id_idx ON staging.customer USING btree (support_rep_id);


--
-- Name: employee_reports_to_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX employee_reports_to_idx ON staging.employee USING btree (reports_to);


--
-- Name: invoice_customer_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX invoice_customer_id_idx ON staging.invoice USING btree (customer_id);


--
-- Name: invoice_line_invoice_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX invoice_line_invoice_id_idx ON staging.invoice_line USING btree (invoice_id);


--
-- Name: invoice_line_track_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX invoice_line_track_id_idx ON staging.invoice_line USING btree (track_id);


--
-- Name: playlist_track_playlist_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX playlist_track_playlist_id_idx ON staging.playlist_track USING btree (playlist_id);


--
-- Name: playlist_track_track_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX playlist_track_track_id_idx ON staging.playlist_track USING btree (track_id);


--
-- Name: track_album_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX track_album_id_idx ON staging.track USING btree (album_id);


--
-- Name: track_genre_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX track_genre_id_idx ON staging.track USING btree (genre_id);


--
-- Name: track_media_type_id_idx; Type: INDEX; Schema: staging; Owner: postgres
--

CREATE INDEX track_media_type_id_idx ON staging.track USING btree (media_type_id);


--
-- PostgreSQL database dump complete
--

