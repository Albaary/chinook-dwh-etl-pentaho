--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dwh_chinook;
--
-- Name: dwh_chinook; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dwh_chinook WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE dwh_chinook OWNER TO postgres;

\unrestrict (null)
\connect dwh_chinook
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: dimension; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA dimension;


ALTER SCHEMA dimension OWNER TO postgres;

--
-- Name: fact_table; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA fact_table;


ALTER SCHEMA fact_table OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_customer; Type: TABLE; Schema: dimension; Owner: postgres
--

CREATE TABLE dimension.dim_customer (
    sk_customer integer,
    version integer,
    customer_id integer,
    customer_name text,
    company text,
    city character varying(100),
    state text,
    country character varying(100),
    email character varying(100),
    date_from timestamp without time zone,
    date_to timestamp without time zone
);


ALTER TABLE dimension.dim_customer OWNER TO postgres;

--
-- Name: dim_date; Type: TABLE; Schema: dimension; Owner: postgres
--

CREATE TABLE dimension.dim_date (
    sk_date integer,
    full_date timestamp without time zone,
    year integer,
    quarter integer,
    month integer,
    day integer,
    day_type text
);


ALTER TABLE dimension.dim_date OWNER TO postgres;

--
-- Name: dim_employee; Type: TABLE; Schema: dimension; Owner: postgres
--

CREATE TABLE dimension.dim_employee (
    sk_employee integer,
    employee_id integer,
    employee_name text,
    title character varying(30),
    city character varying(40),
    country character varying(40)
);


ALTER TABLE dimension.dim_employee OWNER TO postgres;

--
-- Name: dim_track; Type: TABLE; Schema: dimension; Owner: postgres
--

CREATE TABLE dimension.dim_track (
    track_id integer,
    sk_track integer,
    track_name character varying(200),
    album_title character varying(200),
    artist_name character varying(200),
    genre_name character varying(200),
    media_type_name character varying(200),
    composer character varying(400),
    unit_price numeric(12,2),
    duration_category text
);


ALTER TABLE dimension.dim_track OWNER TO postgres;

--
-- Name: fact_sales; Type: TABLE; Schema: fact_table; Owner: postgres
--

CREATE TABLE fact_table.fact_sales (
    transaksi_id integer,
    sk_track integer,
    sk_customer integer,
    sk_date integer,
    sk_employee integer,
    unit_price numeric(12,2),
    quantity integer,
    amount double precision
);


ALTER TABLE fact_table.fact_sales OWNER TO postgres;

--
-- Data for Name: dim_customer; Type: TABLE DATA; Schema: dimension; Owner: postgres
--

COPY dimension.dim_customer (sk_customer, version, customer_id, customer_name, company, city, state, country, email, date_from, date_to) FROM stdin;
\.
COPY dimension.dim_customer (sk_customer, version, customer_id, customer_name, company, city, state, country, email, date_from, date_to) FROM '$$PATH$$/5023.dat';

--
-- Data for Name: dim_date; Type: TABLE DATA; Schema: dimension; Owner: postgres
--

COPY dimension.dim_date (sk_date, full_date, year, quarter, month, day, day_type) FROM stdin;
\.
COPY dimension.dim_date (sk_date, full_date, year, quarter, month, day, day_type) FROM '$$PATH$$/5024.dat';

--
-- Data for Name: dim_employee; Type: TABLE DATA; Schema: dimension; Owner: postgres
--

COPY dimension.dim_employee (sk_employee, employee_id, employee_name, title, city, country) FROM stdin;
\.
COPY dimension.dim_employee (sk_employee, employee_id, employee_name, title, city, country) FROM '$$PATH$$/5025.dat';

--
-- Data for Name: dim_track; Type: TABLE DATA; Schema: dimension; Owner: postgres
--

COPY dimension.dim_track (track_id, sk_track, track_name, album_title, artist_name, genre_name, media_type_name, composer, unit_price, duration_category) FROM stdin;
\.
COPY dimension.dim_track (track_id, sk_track, track_name, album_title, artist_name, genre_name, media_type_name, composer, unit_price, duration_category) FROM '$$PATH$$/5026.dat';

--
-- Data for Name: fact_sales; Type: TABLE DATA; Schema: fact_table; Owner: postgres
--

COPY fact_table.fact_sales (transaksi_id, sk_track, sk_customer, sk_date, sk_employee, unit_price, quantity, amount) FROM stdin;
\.
COPY fact_table.fact_sales (transaksi_id, sk_track, sk_customer, sk_date, sk_employee, unit_price, quantity, amount) FROM '$$PATH$$/5027.dat';

--
-- Name: idx_dim_customer_lookup; Type: INDEX; Schema: dimension; Owner: postgres
--

CREATE INDEX idx_dim_customer_lookup ON dimension.dim_customer USING btree (customer_id);


--
-- Name: idx_dim_customer_tk; Type: INDEX; Schema: dimension; Owner: postgres
--

CREATE INDEX idx_dim_customer_tk ON dimension.dim_customer USING btree (sk_customer);


--
-- Name: idx_dim_track_lookup; Type: INDEX; Schema: dimension; Owner: postgres
--

CREATE INDEX idx_dim_track_lookup ON dimension.dim_track USING btree (track_id);


--
-- PostgreSQL database dump complete
--

